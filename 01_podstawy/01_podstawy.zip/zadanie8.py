l = int(input("Podaj dlugosc: "))
b = int(input("Podaj szerokość"))
h = int(input("Podaj wyskość"))

rozmiar = l*b*h
obj = 1000

print(f"Rozmiar jest rowny: {rozmiar}  i potrzeba jeszcze: {obj - rozmiar} cm")