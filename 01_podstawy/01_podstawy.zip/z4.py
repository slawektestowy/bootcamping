# print(x>2 and x<6)
# print (x >=0 or x < -100)
# print(1==1 and 2 ==3 or 4>2)


z = int(input("Podaj liczbe: "))

# if (z %2!=0):
#     print ("Liczba jest nieparzysta")
# else:
#     print("liczba jest parzysta")

print(f"czy warunek: {z%2 != 0 and z % 3 == 0 and z > 10 or z ==7}")