#liczby calkowite

10
-1000

#float
3.5
2.5
0.5 == .5
xxxx