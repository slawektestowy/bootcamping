# # if
# x = int(input("Podaj liczbe"))
#
# if x > 5:
#     print("duza liczba")
# else:
#     print("Liczba jest mniejsz niz 5")


a = int(input("Podaj liczbe"))

# if a > 10:
#     print("Jest wieksza od 10")
# else:
#     print("liczba jest mniejsza rowna niz 10")


print("czy liczba wieksza niz 10: ", a>10)
print("czy liczba mniejsza niz 15: ", a<15)
print("czy liczba podzielna przez 2: ", a % 2 == 0)

# a = input("Podaj liczbe: ")

# if a > 10 and a <=15 and a %2:
#      print ("wszystko jest ok")
# else:
#     print ("cos poszlo nie tak")