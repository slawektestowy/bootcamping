ru = int(input("Podaj rok urodzenia "))
rb = 2018
w = (rb - ru)

if w > 18:
    print(f"Jestes pelnoletni i masz {w} lata")
else:
    print(f"Nie jestes pelnoletni i masz {w} lat")
