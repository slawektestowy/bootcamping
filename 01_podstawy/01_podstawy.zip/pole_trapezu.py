a = 3
b = 9
h = 6.5



pole = (a+b)*h/2


print(f'Wynik to {pole} cm2')

# w starszych pythonach
print("Pole trapezu to", pole)