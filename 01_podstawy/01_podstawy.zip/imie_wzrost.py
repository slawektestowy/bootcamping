imie = ("Jan")
wzrost = 200

# w dwoch linijkach

print (f'''imie: {imie}
wzrost: {wzrost}''')

print(f'imie: {imie}', f'wzrost: {wzrost}', sep='\n')